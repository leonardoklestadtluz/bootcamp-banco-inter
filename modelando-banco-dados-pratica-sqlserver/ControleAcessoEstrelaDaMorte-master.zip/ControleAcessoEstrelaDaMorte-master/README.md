# ControleAcessoEstrelaDaMorte
Projeto para ajudar na explicação do conteúdo de introdução ao SQL Server na live de 08/02/2021 da Digital Innovation One.
Por favor, não siga este projeto como modelo, ele foi feito de forma simplória para ajudar na explicação.
